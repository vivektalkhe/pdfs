package com.cgapgemini.dto;

import java.io.Serializable;
import java.time.LocalDate;

public class Order implements Serializable{
	
	private int orderId;
	private int productPrice;
	private int customerId;
	private String productName;
	private int noOfproduct;

	
	public int getNoOfproduct() {
		return noOfproduct;
	}

	public void setNoOfproduct(int noOfproduct) {
		this.noOfproduct = noOfproduct;
	}


	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	
	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	@Override
	public String toString() {
		return "Order [productPrice=" + productPrice + ", customerId="
				+ customerId + ", productName=" + productName
				+ ", noOfproduct=" + noOfproduct + "]";
	}




	
}
