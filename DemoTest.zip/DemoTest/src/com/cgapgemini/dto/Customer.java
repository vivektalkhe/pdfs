package com.cgapgemini.dto;

import java.io.Serializable;
import java.sql.Date;
import java.time.LocalDate;

public class Customer implements Serializable {


	private static final long serialVersionUID = 1L;
	
	
	private int customerId;
	private String customertName;
	private String phoneNumber;
	private String emailId;
	private String city;
	private int availableProduct;
	private Date date;
	
	

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomertName() {
		return customertName;
	}

	public void setCustomertName(String customertName) {
		this.customertName = customertName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	public Customer() {
	}

	public int getAvailableProduct() {
		return availableProduct;
	}

	public void setAvailableProduct(int availableProduct) {
		this.availableProduct = availableProduct;
	}

	
	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customertName="
				+ customertName + ", phoneNumber=" + phoneNumber + ", emailId="
				+ emailId + ", city=" + city + ", availableProduct="
				+ availableProduct + ", date=" + date + "]";
	}

	

	
	
	
}
