package com.capgemini.exceptions;

public class OrderException extends Exception {

	public OrderException() {
		// TODO Auto-generated constructor stub
	}

	public OrderException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public OrderException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public OrderException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public OrderException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
