package com.capgemini.client;

import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.exceptions.OrderException;
import com.capgemini.service.CustomerOrderServiceImpl;
import com.capgemini.service.ICustomerOrderService;
import com.capgemini.util.DbUtil;
import com.cgapgemini.dto.Customer;
import com.cgapgemini.dto.Order;

public class MainClient {

	static Order order=new Order();
	public static void main(String[] args) throws OrderException {

		//private static final Logger mylogger = Logger.getLogger(MainClient.class);
		ICustomerOrderService icustorder=new CustomerOrderServiceImpl();
		int choice=0;
		
		do
		{
		orderProduct();
		Scanner src=new Scanner(System.in);
		choice = src.nextInt();
		switch(choice)
		{
		case 1:
		// Show All
			List<Customer> cust = null;
			try {
				cust = icustorder.showAll();
				for (Customer customer : cust) {

					// System.out.print(mobile.getMobileid()+"  "+mobile.getMname()+"      "+mobile.getPrice()+" "+mobile.getQuantity());
					System.out.println(customer);
				}				
			} catch (OrderException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			break;
		
		case 2:
			
			//Inserting order details
			
			String pdName;
			int custId;
			int numberOfProd;
			
			src.nextLine();
			System.out.println("Enter Product Name");
			pdName=src.nextLine();

			System.out.println("Enter Customer ID");
			custId=src.nextInt();
			
			System.out.println("Enter No Of Product to purchase");
			numberOfProd=src.nextInt();
			
			order.setCustomerId(custId);
			order.setProductName(pdName);
			
			try {
				icustorder.orderProduct(order);
			} catch (OrderException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new OrderException("Check Your Data");
			}
			
			break;
			
		case 3:
			
			//Exit
			System.out.println("Exit");
			break;
		default:
			System.out.println("Invalid Choice");
			break;
			
			
			
			
		/*case 4:// Remove Employees
			System.out
					.println("Enter The ID Of Record That You Want To Remove");
			int id = scr.nextInt();
			try {
				imobile.deleteMobile(id);
			} catch (MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		*/
		}
		}while(choice!=3);
		}
	public static void orderProduct() {
		System.out.println("**********");
		System.out.println("1.Show Order Product ");
		System.out.println("2.Purchase Product");
		System.out.println("3.Exit");
		System.out.println("***********");
}
}
