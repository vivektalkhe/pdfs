package com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.exceptions.OrderException;
import com.capgemini.util.DbUtil;
import com.cgapgemini.dto.Customer;
import com.cgapgemini.dto.Order;

public class CustomerOrderImpl implements ICustomerOrder {
	
	
	
	
	Order order=new Order();
	public CustomerOrderImpl() {
	}

	@Override
	public List<Customer> showAll() throws OrderException {
		
		System.out.println("In Show Method");
		Connection conn=DbUtil.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		List<Customer> cusList=new ArrayList<Customer>();
		String query="select * from customer1";
		
		try {
			ps=conn.prepareStatement(query);
			rs=ps.executeQuery();
			while(rs.next())
			{
				int custId=rs.getInt("customer_Id");
				String custName=rs.getString("customer_Name");
				String custphNumber=rs.getString("phone_Number");
				String custCity=rs.getString("city");
				String custeId=rs.getString("emailId");
				int custAvlProduct=rs.getInt("availableProduct");
				System.out.println(custAvlProduct);
				Date custProdDate=rs.getDate("PDATE");
				System.out.println(custProdDate);
				String d = custProdDate.toString();
				LocalDate mainDate = LocalDate.parse(d);
				
				Customer customer=new Customer();
				customer.setCustomerId(custId);
				customer.setCustomertName(custName);
				customer.setPhoneNumber(custphNumber);
				customer.setCity(custCity);
				customer.setEmailId(custeId);
				customer.setAvailableProduct(custAvlProduct);
				customer.setDate(custProdDate);
				cusList.add(customer);
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new OrderException("Does Not Show Details");
		}
		finally
		{
			try {
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return cusList;
	}

	@Override
	public int orderProduct(Order order) throws OrderException {
		
		int rec = 0;
		int orderId=0;
		Connection  conn = DbUtil.getConnection();
		PreparedStatement ps=null;
		//ResultSet rs=null;
		
		String insertQuery = "INSERT INTO orders1 VALUES(?,?,?,?,?)";
		
			try {
				orderId=getOrderId();
				ps = conn.prepareStatement(insertQuery);
				ps.setInt(1, orderId);
				ps.setString(2, order.getProductName());
				ps.setInt(3,order.getProductPrice());
				ps.setInt(4, order.getNoOfproduct());
				ps.setInt(5, order.getCustomerId());
				System.out.println(orderId+" "+order.getCustomerId()+" " +getOrderId());
				boolean check = checkProduct(order.getNoOfproduct(),order.getCustomerId());

				System.out.println(check);
				if (check == true) {
					rec = ps.executeUpdate();
					if (rec>0) {
						System.out.println("Thank You.Your Order Product IS"
								+ orderId);
						System.out.println("Record Inserted Successfully");


						updateSeat(order.getCustomerId(),
								order.getNoOfproduct());

					}
				} else {
					throw new OrderException("Sorry No Product Are Available");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally{
				
			
				try {
					ps.close();
				
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		
		
		
		return orderId;
	}
	
	private boolean updateSeat(int customerId, int noOfproduct) throws OrderException {


		
		Connection  conn = DbUtil.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		String query = "UPDATE customer1 SET availableproduct=availableproduct-? WHERE customer_id=?";
		int rec = 0;
		try {
			ps = conn.prepareStatement(query);
			ps.setInt(1, noOfproduct);
			ps.setInt(2, customerId);
			rec = ps.executeUpdate();
			if (rec > 0) {
				System.out.println("data is updated successfully");
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new OrderException("Data is not updated properly");
		} 
		finally{
			try {
				ps.close();
			
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}

	private boolean checkProduct(int noOfproduct, int customerId) {
		
		int nOfProd=0;
		int cid=0;
		
		Scanner sc = new Scanner(System.in);
		Connection  conn = DbUtil.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		String query1 = "SELECT availableproduct FROM customer1 WHERE customer_id=?";

		try {
			ps = conn.prepareStatement(query1);
			ps.setInt(1, customerId);
			rs = ps.executeQuery();
			while (rs.next()) {
				nOfProd = rs.getInt("availableproduct");

			}
			if (nOfProd > 0 && nOfProd >=noOfproduct) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
		finally
		{
			try {
				ps.close();
				rs.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;

	}
		
		

	public int getOrderId() throws OrderException {
		int id = 0;

		Connection  conn = DbUtil.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		String query = " select order_id_seq.nextval from dual";
		try {
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();
			while (rs.next()) {
				id = rs.getInt(1);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new OrderException("No Sequence Created");
		} 
		finally{
			
			
			try {
				ps.close();
				rs.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return id;

	}
}
