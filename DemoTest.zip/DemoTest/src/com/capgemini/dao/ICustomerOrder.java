package com.capgemini.dao;

import java.util.List;

import com.capgemini.exceptions.OrderException;
import com.cgapgemini.dto.Customer;
import com.cgapgemini.dto.Order;

public interface ICustomerOrder {
	
	List<Customer> showAll() throws OrderException;
	int orderProduct(Order order) throws OrderException;
	//boolean updateProduct(int customerId, int availableProduct ) throws OrderException;
	//boolean deleteProduct(int customerid) throws OrderException;
	
	
	
	

}
