package com.capgemini.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.dao.CustomerOrderImpl;
import com.capgemini.dao.ICustomerOrder;
import com.capgemini.exceptions.OrderException;
import com.cgapgemini.dto.Customer;

public class TestCustomerOrder {
	
	
	ICustomerOrder impl;
	Customer customer; 

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		
		impl=new CustomerOrderImpl();
		customer=new Customer();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws OrderException {

	
try {
	assertNotNull(impl.showAll());
} catch (OrderException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	throw new OrderException("DATA IS NOT RETRIEVE PROPERLY");
}
	}
	
	/*public static void main(String args[])
	{
		
		
		
		
	}*/
}
