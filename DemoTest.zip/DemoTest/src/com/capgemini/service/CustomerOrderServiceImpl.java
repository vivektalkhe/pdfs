package com.capgemini.service;

import java.util.List;

import com.capgemini.dao.ICustomerOrder;
import com.capgemini.dao.CustomerOrderImpl;
import com.capgemini.exceptions.OrderException;
import com.cgapgemini.dto.Customer;
import com.cgapgemini.dto.Order;

public class CustomerOrderServiceImpl implements ICustomerOrderService {
	
	ICustomerOrder productorder;

	public CustomerOrderServiceImpl() {
		
		productorder=new CustomerOrderImpl();
	}

	@Override
	public List<Customer> showAll() throws OrderException {
		
		return productorder.showAll();
	}

	@Override
	public int orderProduct(Order order) throws OrderException {
		

		return productorder.orderProduct(order);
	}

}
