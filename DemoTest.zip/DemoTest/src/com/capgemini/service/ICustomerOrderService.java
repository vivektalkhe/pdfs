package com.capgemini.service;

import java.util.List;

import com.capgemini.exceptions.OrderException;
import com.cgapgemini.dto.Customer;
import com.cgapgemini.dto.Order;

public interface ICustomerOrderService {

	List<Customer> showAll() throws OrderException;
	int orderProduct(Order order) throws OrderException;


}
