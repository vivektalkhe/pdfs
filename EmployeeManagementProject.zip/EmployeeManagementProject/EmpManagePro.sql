select * from employeemanagement;

delete from employeemanagement;