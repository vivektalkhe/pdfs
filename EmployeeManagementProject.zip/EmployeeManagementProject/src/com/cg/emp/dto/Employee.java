package com.cg.emp.dto;

import java.io.Serializable;

public class Employee implements Serializable {
	
	private int empId;
	private String empName;
	private String empQualification;
	private double empSalary;
	
	
	public Employee() {
		super();
	}
	public Employee(int empId, String empName, String empQualification,
			double empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empQualification = empQualification;
		this.empSalary = empSalary;
	}
	public int getEmpId() {
		return empId;
	}
	public String getEmpName() {
		return empName;
	}
	public String getEmpQualification() {
		return empQualification;
	}
	public double getEmpSalary() {
		return empSalary;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public void setEmpQualification(String empQualification) {
		this.empQualification = empQualification;
	}
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", empQualification=" + empQualification + ", empSalary="
				+ empSalary + "]";
	}
}