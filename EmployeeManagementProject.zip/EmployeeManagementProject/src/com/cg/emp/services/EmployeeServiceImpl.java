package com.cg.emp.services;

import java.sql.SQLException;
import java.util.List;

import com.cg.emp.dao.EmployeeDaoImpl;
import com.cg.emp.dao.IEmployeeDao;
import com.cg.emp.dto.Employee;
import com.cg.emp.exceptions.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {
	IEmployeeDao empDao;
	

	public EmployeeServiceImpl() {
empDao=new EmployeeDaoImpl();	
}

	@Override
	public int addEmployee(Employee emp) throws EmployeeException, SQLException {
		return empDao.addEmployee(emp);
	}

	@Override
	public List<Employee> showAll() throws EmployeeException {
		return empDao.showAll();
	}

	@Override
	public Employee getEmployee(int empId) throws EmployeeException {

		return empDao.getEmployee(empId);
	}

	@Override
	public Employee UpdateEmp(Employee e) throws EmployeeException {
		return empDao.UpdateEmp(e);
	}

	@Override
	public boolean DeleteEmp(int empId) throws EmployeeException {
		return empDao.DeleteEmp(empId);
	}

}
