package com.cg.emp.services;

import java.sql.SQLException;
import java.util.List;

import com.cg.emp.dto.Employee;
import com.cg.emp.exceptions.EmployeeException;

public interface IEmployeeService {
	
	public int addEmployee(Employee emp) throws EmployeeException, SQLException;
	public List<Employee> showAll() throws EmployeeException;
	public Employee getEmployee(int empId) throws EmployeeException;
	public Employee UpdateEmp(Employee e) throws EmployeeException;
	public boolean DeleteEmp(int empId) throws EmployeeException;

}
