package com.cg.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;







import com.cg.emp.dto.Employee;
import com.cg.emp.exceptions.EmployeeException;
import com.cg.emp.utl.DbUtil;

public class EmployeeDaoImpl implements IEmployeeDao {

	@Override
	public int addEmployee(Employee emp) throws EmployeeException, SQLException
	{
		Connection conn=null;
		PreparedStatement pstm=null;
		int empid = getEmployee();
		int msg=0;
		
		String query="INSERT INTO employeemanagement VALUES(?,?,?,?)";
		
		try {
			conn=DbUtil.obtainConnection();
			pstm=conn.prepareStatement(query);
			pstm.setInt(1, empid);
			pstm.setString(2,emp.getEmpName());
			pstm.setString(3, emp.getEmpQualification());
			pstm.setDouble(4, emp.getEmpSalary());
			int status=pstm.executeUpdate();
			if(status==1)
			{
				msg=empid;
				System.out.println("Record is inserted");
			}
		} catch (EmployeeException e) {

			throw new EmployeeException("Data Not Inserted");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new EmployeeException("Insertion Not Called In Dao");
		}
		finally
		{
			if(pstm!=null)
			{
				try {
					pstm.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(conn!=null)
			{
				try {
					conn.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
			}
		
		}
		return msg;
	}

	@Override
	public List<Employee> showAll() throws EmployeeException {
		
		
		Connection conn=null;
		PreparedStatement pstm=null;
		ResultSet res=null;
		List<Employee> myEmp=new ArrayList<Employee>();
		String query="select emp_id,emp_name,emp_qual,emp_sal from employeemanagement";
		try {
			conn=DbUtil.obtainConnection();
			pstm=conn.prepareStatement(query);
			
			res=pstm.executeQuery();
			while (res.next())
			{
				Employee e=new Employee();
				e.setEmpId(res.getInt("emp_id"));
				e.setEmpName(res.getString("emp_name"));
				e.setEmpQualification(res.getString("emp_qual"));
				e.setEmpSalary(res.getDouble("emp_sal"));
				myEmp.add(e);
				
			}
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmployeeException("Problem In Show");
		}
		finally
		{
			if(pstm!=null)
			{
				try {
					pstm.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(conn!=null)
			{
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(res!=null)
				
					{
				try {
					res.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		
		return myEmp;
	}
	public int getEmployee() throws SQLException, EmployeeException
	{
		int empid=0;
		Connection conn=null;
		PreparedStatement pstm=null;
		ResultSet res=null;
		String query="SELECT empm_id_seq.NEXTVAL FROM DUAL";
		
		
			try {
				conn=DbUtil.obtainConnection();
				pstm=conn.prepareStatement(query);
				res=pstm.executeQuery();
				while(res.next())
				{
					empid=res.getInt(1);
					System.out.println(empid);
					
				}
			} catch (EmployeeException e) {
			
				throw new EmployeeException("Sequence not created");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Sequence not created"+e);
			}
			finally
			{
				if(pstm!=null)
				{
					pstm.close();
				}
				if(conn!=null)
				{
					conn.close();
				}
				if(res!=null)	
				{
					res.close();
				}
			}
		return empid;
	}

	@Override
	public Employee getEmployee(int empid) throws EmployeeException {
		Connection conn=null;
		PreparedStatement pstm=null;
		Employee emp=new Employee();
		String query="select emp_id,emp_name,emp_qual,emp_sal from employeemanagement where emp_id=?";
		try {
			conn=DbUtil.obtainConnection();
			pstm=conn.prepareStatement(query);
			pstm.setInt(1,empid);
			ResultSet res=pstm.executeQuery();
			while(res.next())
			{	
			emp.setEmpId(res.getInt("emp_id"));
			emp.setEmpName(res.getString("emp_name"));
			emp.setEmpQualification(res.getString("emp_qual"));
			emp.setEmpSalary(res.getDouble("emp_sal"));
			}
		} catch (Exception e) {

			e.printStackTrace();
		}
		return emp;
}

	@Override
	public Employee UpdateEmp(Employee e) throws EmployeeException {
		Connection conn=null;
		PreparedStatement pstm=null;
		ResultSet rs=null;
		String UpdateId="update employeemanagement set emp_id=?,emp_name=?,emp_qual=?,emp_sal=? where emp_id=?";
		
		try {
			conn=DbUtil.obtainConnection();
			pstm=conn.prepareStatement(UpdateId);
			pstm.setInt(1, e.getEmpId());
			pstm.setString(2, e.getEmpName());
			pstm.setString(3, e.getEmpQualification());
			pstm.setDouble(4, e.getEmpSalary());
			pstm.setInt(5, e.getEmpId());
			int flag=pstm.executeUpdate();
			if(flag==1)
			{
				System.out.println("Record is Inserted");
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			System.out.println("Not Update");
		}
		return e;
	}
	@Override
	public boolean DeleteEmp(int empId) throws EmployeeException {
		Connection conn=null;
		PreparedStatement pstm=null;
		ResultSet rs=null;
		String deleteEmp="delete employeemanagement where emp_id=?";
		try {
			conn=DbUtil.obtainConnection();
			pstm=conn.prepareStatement(deleteEmp);
			pstm.setInt(1,empId);
			int flag=pstm.executeUpdate();
			if(flag==1)
			{
				System.out.println("Record is updated");
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Not Delete");
		}
		return false;
	}
}