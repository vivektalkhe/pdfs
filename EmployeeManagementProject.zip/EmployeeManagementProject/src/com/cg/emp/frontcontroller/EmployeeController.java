package com.cg.emp.frontcontroller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.emp.dto.Employee;
import com.cg.emp.exceptions.EmployeeException;
import com.cg.emp.services.EmployeeServiceImpl;
import com.cg.emp.services.IEmployeeService;

@WebServlet("*.do")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IEmployeeService employeeService;
   

	@Override
	public void destroy() {
		employeeService=null;
	}
	@Override
	public void init() throws ServletException {
		employeeService=new EmployeeServiceImpl();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 try {
			processRequest(request,response);
		} catch (EmployeeException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
    private void processRequest(HttpServletRequest request,HttpServletResponse response) throws EmployeeException
    {
    	String path=request.getServletPath();
    	System.out.println(path);
		if(path.equals("/employeeController.do"))
		{
		RequestDispatcher resdis=request.getRequestDispatcher("addEmployee.jsp");
		try {
			resdis.forward(request, response);
		} catch (ServletException e) 
		{
			e.printStackTrace();
		} catch (IOException e) 
		{	
			e.printStackTrace();
		}
		}
		if(path.equals("/empadd.do"))
		{
			Employee emp=new Employee();
			String name=request.getParameter("jname");
			String qualification=request.getParameter("jqual");
			String salary=request.getParameter("jsal");
			emp.setEmpName(name);
			emp.setEmpQualification(qualification);
			emp.setEmpSalary(Double.parseDouble(salary));
			try {
				int empid=employeeService.addEmployee(emp);
				System.out.println(empid);
				request.setAttribute("id", empid);
				
				RequestDispatcher req=request.getRequestDispatcher("welcome.jsp");	
				req.forward(request,response);
				
				
			} catch (Exception e) {
			
				throw new EmployeeException("Insertion method not called",e);
			}
		}

		 if(path.equals("/showall.do"))
		{
			try {
				List<Employee> myList=employeeService.showAll();
				System.out.println(myList);
				request.setAttribute("data", myList);
				RequestDispatcher req=request.getRequestDispatcher("showAll.jsp");
				req.forward(request, response);
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
			else if(path.equals("/update.do"))
			{
				//System.out.println("Update.......");
				String data=request.getQueryString();
				String empid=data.substring(3, 7);
				System.out.println(data);
				int id=Integer.parseInt(empid);
				Employee eData=employeeService.getEmployee(id);
				request.setAttribute("empData", eData);
				RequestDispatcher res=request.getRequestDispatcher("updateemployee.jsp");
				try {
					res.forward(request, response);
				} catch (ServletException | IOException e) {
					e.printStackTrace();
				}
			}
		 if(path.equals("/updatedata.do"))
		 {
			 String id=request.getParameter("id");
			 int eid=Integer.parseInt(id);
			 String name=request.getParameter("name");
			 String qual=request.getParameter("qual");
			 String sal=request.getParameter("sal");
			 double esal=Double.parseDouble(sal);
			 Employee e=new Employee(eid,name,qual,esal);
			 e=employeeService.UpdateEmp(e);
			 System.out.println(e);
			 request.setAttribute("newdata",e);
		 }
		 if(path.equals("/delete.do"))
		 {
			 String id=request.getQueryString();
			 String empId=id.substring(3, 7);
			 int eid=Integer.parseInt(empId);
			 System.out.println(eid);
			 boolean delete=employeeService.DeleteEmp(eid);
			 if(delete==true)
			 {
				 System.out.println("Data is Deleted");
				 RequestDispatcher req=request.getRequestDispatcher("updatedata.jsp");
				 try {
					req.forward(request, response);
				} catch (ServletException e) {
					
					e.printStackTrace();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			 }
			 else{
				 throw new EmployeeException("data is not able to update");
			 	}		 
		 }
	}	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (EmployeeException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}