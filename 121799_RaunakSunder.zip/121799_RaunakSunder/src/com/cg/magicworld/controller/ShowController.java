package com.cg.magicworld.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cg.magicworld.dto.Show;
import com.cg.magicworld.exception.ShowException;
import com.cg.magicworld.services.IShowService;

@WebServlet("*.do")
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private IShowService services;
	private RequestDispatcher dispatch;
	private String nextJsp;
	ServletContext ctx=null; 
 
	public void init() throws ServletException {
		ctx=super.getServletContext();
	    services=(IShowService)ctx.getAttribute("services");    //Getting object From Listener
	}

	 private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException, ShowException{
	    	String command=request.getServletPath();
	        ctx.log("Command:" + command);
	        List<Show> myList=null;;
	        switch(command){
	        case "/showDetails.do":{
	        		myList=new ArrayList<>();
					myList=services.showAll();
					request.setAttribute("list",myList);
					nextJsp="/showDetails.jsp";	   
					break;
	        }
	        case "/book.do":
	        {
	        	String name=request.getParameter("name");
	        	String price=request.getParameter("price");
	        	String seats=request.getParameter("seats");
	        	request.setAttribute("showName", name);
	        	request.setAttribute("showPrice", price);
	        	request.setAttribute("showSeats", seats);
	        	nextJsp="bookNow.jsp";
	        	break;
	        }
	        case "/update.do":
	        {
	        	String seatsStr=request.getParameter("seats");
	        	String showName=request.getParameter("showName");
	        	int seats=Integer.parseInt(seatsStr);
	        	String price=request.getParameter("price");
			    String name=request.getParameter("name");
			    String mobile=request.getParameter("mobile");
			    String avSeats=request.getParameter("avSeats");
			    double Price=Double.parseDouble(price);
			    double totalPrice=seats*Price;
	        	int update=services.updateSeats(seats,showName);

	        	if(update==1)
	        	{
	        	ctx.log("Updation Of Seats Successfull");
		       
		        String total=String.valueOf(totalPrice);
		        request.setAttribute("showName",showName);
		        request.setAttribute("totalPrice",total);
		        request.setAttribute("name",name);
		        request.setAttribute("mobile",mobile);
		        request.setAttribute("bookSeats",seatsStr);
	        	nextJsp="/success.jsp";
	        	}
	        	else
	        	{
	            ctx.log("Updation of Seats Failed");
	        	nextJsp="/error.jsp";
	        	}
	        }
	        }
	    
	        dispatch=request.getRequestDispatcher(nextJsp);
	        dispatch.forward(request, response);
	           }

	

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request,response);
		} catch (ShowException e) {
		
			e.printStackTrace();
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request,response);
		} catch (ShowException e) {
			
			e.printStackTrace();
		}
	}
	
	public void destroy() {
		services=null;
	}

}
